import java.io.*;
public class Bank {
	// Declaration of private variables for the Bank class
private String bankName;
private double comRate;
private String curCode;
private Currency cur1;
private Currency cur2;
private Currency cur3;
private Quote quote;
// Creates a file for the bank; 
public Bank(String fileName) throws FileNotFoundException { 
	File file = new File(fileName);
	PrintWriter pw = new PrintWriter(file);
	pw.println(bankName);
	pw.println(comRate);
	pw.println(cur1);
	pw.println(cur2);
	pw.println(cur3);
}
// Finds if the bank will support the currency
public boolean supportCurrency(String currCode) {
currCode=curCode;
String curr1=cur1.getCode();
String curr2=cur2.getCode();
String curr3=cur3.getCode();
if (curCode==curr1 || curCode==curr2 || curCode==curr3) {
	return true;
}
else {
	return false;
}
}
// will get the rate for each currency from the currency class
public double getRate(String CurCode) {
CurCode=curCode;
if(curCode==cur1.getCode()) {
	double cur1Rate=cur1.getRate();
	return cur1Rate;
}
else if(curCode==cur2.getCode()) {
	double cur2Rate=cur2.getRate();
	return cur2Rate;
}
else if(curCode==cur3.getCode()) {
	double cur3Rate = cur3.getRate();
	return cur3Rate;
}
else {
	return -1.0;
}
}
// will use the currency code, the bank name and the Quote class
// to develop a quote from the bank
public Quote quoteBuy(double curAmt, String curCcode) { 
	curCcode=curCode;
	double cr=comRate; 
	String bn=bankName;
	if (supportCurrency(curCode)==true) {
	double dollarsOwed = curAmt/(getRate(curCode)*(1-comRate));	
	double com=comRate*dollarsOwed;
	double dO = dollarsOwed+com;
	quote = new Quote(bankName, curCode, curAmt, "USD", dO, comRate, com);
	return quote;
	}
	else {
		return null;
	}
}
// uses everything from the quoteBuy method to develop the quote for 
// selling currency
public Quote quoteSell(double curAmt, String ccurCode) {
	ccurCode=curCode;
	double base = curAmt/comRate;
	double commission = comRate*base*curAmt;
	double receive = base-commission;
	String bn=bankName;
	if (supportCurrency(curCode) == true) {
		quote = new Quote(bankName, "USD", curAmt, curCode, receive, comRate, commission);
		return quote;
	}
	else {
		return null;
	}
}
}

