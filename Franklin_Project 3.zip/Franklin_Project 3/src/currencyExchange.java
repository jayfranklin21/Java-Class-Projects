/* Karun Jason Franklin 
 * CS160 Project 3
 */
import java.util.Scanner;
import java.io.*;
public class currencyExchange {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		// makes 2 new files and writes the information about the bank to the file
		File file = new File("Bank1.txt");
		File file2 = new File("Bank2.txt");
		PrintWriter pw = new PrintWriter(file);
		PrintWriter pw2 = new PrintWriter(file2);
		Currency cur11 = new Currency("GBP", .64);
		Currency cur12 = new Currency ("CAD", 1.24);
		Currency cur13 = new Currency("INR", 74.2);
		Currency cur21 = new Currency("JPY", 109.61);
		Currency cur22 = new Currency("CAD", 1.07);
		Currency cur23 = new Currency("CHF", 1.01);
		pw.println("Shady Airport Bank");
		pw.println(".2");
		pw.println(cur11);
		pw.println(cur12);
		pw.println(cur13);
		pw2.println("Big Name Bank");
		pw2.println(".09");
		pw2.println(cur21);
		pw2.println(cur22);
		pw2.println(cur23);
		pw.close();
		pw2.close();
		// makes a new Bank object for each bank
		Bank bank1 = new Bank("Bank1.txt");
		Bank bank2 = new Bank("Bank2.txt");
		System.out.println("If you want ot buy, press 1");
		System.out.println("If you want to sell, press 2");
		Scanner kb = new Scanner(System.in);
		// used if the user wants to buy a currency
		if (kb.nextInt() == 1) {
			System.out.println("What currency would you like to buy?");
			String curCode = kb.next();
			if (bank1.supportCurrency(curCode)==true) {
				if (bank2.supportCurrency(curCode)==true) {
					System.out.println("2 banks support that currency.");
				}
				else if(bank2.supportCurrency(curCode)==false) {
					System.out.println("1 bank supports that currency.");
				}
			}
			else if (bank2.supportCurrency(curCode)==true) {
				System.out.println("1 bank supports that currency.");
			}
			else {
				System.out.println("No banks support that currency. :(");
			}
			System.out.println("How much " + curCode + " do you want to buy");
			double amt = kb.nextDouble();
			if (bank1.supportCurrency(curCode)==true) {
				Quote quoteBuy = bank1.quoteBuy(amt, curCode);
				System.out.println(quoteBuy.toString());
			}
			else if(bank2.supportCurrency(curCode)==true) {
				Quote quote = bank2.quoteBuy(amt, curCode);
				System.out.println(quote.toString());
			}
			
		}
		// used if the user wants to sell currency
		else if (kb.nextInt() == 2) { 
			System.out.println("What currency would you like to sell?");
			String curCode = kb.next();
			if (bank1.supportCurrency(curCode)==true) {
				if (bank2.supportCurrency(curCode)==true) {
					System.out.println("2 banks support that currency.");
				}
				else if(bank2.supportCurrency(curCode)==false) {
					System.out.println("1 bank supports that currency.");
				}
			}
			else if (bank2.supportCurrency(curCode)==true) {
				System.out.println("1 bank supports that currency.");
			}
			else {
				System.out.println("No banks support that currency. :(");
				
			}
			System.out.println("How much " + curCode + " do you want to sell?");
			double amt = kb.nextDouble();
			if (bank1.supportCurrency(curCode)==true) {
				Quote quoteSell = bank1.quoteSell(amt, curCode);
				System.out.println(quoteSell.toString());
			}
			if (bank2.supportCurrency(curCode)) {
				Quote quote = bank2.quoteSell(amt,  curCode);
				System.out.println(quote.toString());
			}
		}
		else {
			System.out.println("Try Again, Bud...");
			
		}
	}

}
