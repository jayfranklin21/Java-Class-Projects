
public class Currency {
private String code;
private double rate; 
// takes the currency code and the rate to be used in other classes
public Currency (String c, double r) {
	r=rate;
	c=code;
}
public String getCode() {
	return code;
}
public double getRate() {
	return rate;
}
}

