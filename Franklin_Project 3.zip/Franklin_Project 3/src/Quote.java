
public class Quote {
private String bankName;
private String codeToBank;
private double amtToBank;
private String codeFromBank;
private double amtFromBank;
private double comRate;
private double comAmt;
// takes 7 arguments for each of the above variables to develop a quote from the bank
public Quote(String bn, String ctb, double atb, String cfb, double afb, double cr, double ca) {
	bn=bankName;
	ctb=codeToBank;
	atb=amtToBank;
	cfb=codeFromBank;
	afb=amtFromBank;
	cr=comRate;
	ca=comAmt;
}
// puts the quote into a string message that will be displayed once the quote is developed
public String toString() {
	String message= (bankName + "will give you " + amtFromBank + codeFromBank + "for " + 
			amtToBank +  codeToBank + "after collecting " + comAmt +"(" + comRate + ")");;
	return message;
}
}
