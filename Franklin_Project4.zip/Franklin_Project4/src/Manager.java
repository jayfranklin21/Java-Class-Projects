import java.util.Random;
public class Manager {
Garage garage; 
final double feePerHour = 1.50;
double feeTotal;
int manyCars;
public Manager(Garage gar, int many) {
	gar=garage;
	many=manyCars;
}
public void parkACar() {
	// puts a car in the first available bay and increases the number of cars in the garage
	int index = garage.park(new Car());
	if (index!=-1) {
		System.out.println("A car is arriving in bay #" + index + "/n Garage is displayed on "
				+ "console");
		manyCars++;
		garage.displayState();
	}
	else if(index==-1) {
		// if there are no more bays, it return this message and the program will shut down
		System.out.println("The Garage is full. Sorry, bud.");
	}
}
public void chooseACarToLeave() {
	// will remove a car from its bay
	if (manyCars == 0) {
		System.out.println("The garage is empty. Good night.");
	}
	else {
		Random rd = new Random();
		int rand = rd.nextInt(1)+manyCars;
		int index = garage.findBayOfCar(rand);
		double timeOut = garage.remove(index);
		Car car = new Car();
		double timeIn = car.getTime();
		double fee = feePerHour*(timeIn - timeOut);
		feeTotal = feeTotal+fee;
		System.out.println("The car from bay "+index+"is leaving");
		System.out.println("Parking fee of" + fee + "has been paid");
		garage.displayState();
		manyCars--;
	}
}
public void processParking (int limit) {
	System.out.println("Welcome to the Parking Garage simulator!");
	System.out.println("Here is the initial state of the garage");
	garage.displayState();
	Random rand = new Random();
	int r = rand.nextInt(2)+1; // makes it so there is 50/50 chance for parking a car, or removing a car
	for (int l = limit; l>=0; l--) {
		if (r==1) {
			parkACar();
		}
		else if (r==2) {
			chooseACarToLeave();
		}
	}
	System.out.println("Total parking fee collected = " + feeTotal);
	System.out.println("It took " + limit + "tries to complete the process");
	System.exit(0);
}
}
