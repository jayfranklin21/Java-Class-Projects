
public class Garage {
Car Cars[];
public Car[] getCars() {
	return Cars;
}
public void setCars(Car auto, int index) {
	Cars[index] = new Car();
	auto = Cars[index];
}
public boolean isEmpty(int k) {
	//if a parking bay is empty, it returns that there are no cars in said bay
	return Cars[k] == null;
}
public void displayState() {
	// will display the state of the garage in a linear format
	int count = Cars.length;
	for (int x = count; x>=0; x--) {
		// displays each bay number 
		System.out.print(x + "/t");
	}
	for (int y = count; y>=0; y--) {
		//displays whether or not the bay has a car in it or is Empty
		if (isEmpty(y)) {
			System.out.print("E" + "/t");
		}
		else {
			System.out.print("C" + "/t");
		}
	}
}
public int park(Car auto) {
	// if a bay is empty, garage.park() fills it with a car
	int bay = -1;
	for (int index=0; index<Cars.length; index++) {
		if (isEmpty(index)) {
			bay++;
			boolean parked = isEmpty(index);
			parked = false;
		}
	}
	return bay;
}
public double remove (int index) {
	//removes a car from its bay
	double timeOut = Cars[index].getTime();
	Cars[index] = null;
	return timeOut;
}
public int findBayOfCar(int carNumber) {
	//will return the bay of a specific car
	int index=-1;
	for (int cn=carNumber; cn>=0; cn=0) {
		index++;
		while(isEmpty(index)==false) {
			index++;
		}
	}
	return index;
}
public Garage(int capacity) {
	Car car = Cars[capacity];
}
}
