import java.util.Random;
public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int garageCapacity = 15;
		final int limit = 15; 
		Garage garage = new Garage(garageCapacity);
		int counter=0;;
		int index=0;
		Car car[] = new Car[index];
		Random rand = new Random();
		for(index=0; index<=garageCapacity; index++) { // randomly sets the initial state of the garage
			int r = rand.nextInt(2)+1;
			if (r==1) {
				garage.isEmpty(index);
				garage.park(car[index]);
				counter++;
			}
		}
		Manager man = new Manager(garage, counter);
		man.processParking(limit); // runs the parking simulation 
		
	}

}
