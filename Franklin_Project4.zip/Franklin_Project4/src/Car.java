/* Karun Jason Franklin 
 * Project 4 for Dr. V CS160
 */
public class Car {
	long timeIn;
public void Car() {
	timeIn = System.currentTimeMillis();
	//Sets the time the Car enters to the current time
}
public long getTime() {
	return timeIn;
}
}
